---
name: tw-spark-edu-lesson-pack-generator
description: 依據教材課本內容或教學章節PDF，自動規劃並輸出全套素養導向教學資源包（教案、學習單、課堂提問表、分層測驗卷、分組任務卡、考前精華筆記），並用genoffice在本機工作資料夾生成DOCX、PPTX、PNG結構圖、Kahoot XLSX，不上傳雲端。當使用者要求由課本PDF/教材生成全套備課包、教學資源包、完整教案與配件並存本機時使用。
allowed-tools: genoffice
---

# 臺灣 K-12 全套備課包生成器 (tw-spark-edu-lesson-pack-generator)

專為臺灣國小、國中與高中教師打造的一站式備課工作流。將教科書章節 PDF 或教材內容轉化為完整 108 課綱素養導向教學套件，全部用 genoffice 在本機工作資料夾輸出，不上傳雲端。

## 適用情境 (When to Use)

- 使用者提供課本 PDF、課文內容、或指定年級單元主題，要求產出完整教案與教學配件。
- 使用者要求生成全套備課資源包（包含教案、學習單、Bloom 提問表、分層測驗卷、分組任務卡、CheatSheet）。
- 使用者要求成果為本機 DOCX、PPTX、PNG、XLSX，存放在工作資料夾，可直接用 Word / PowerPoint / Excel 開啟。

## 執行流程 (Workflow Steps)

### 步驟 1：教材解析與課綱對齊

1. 閱讀使用者提供的課本內容或 PDF 文本（`genoffice pdf read <pdf> --full` 或 `genoffice convert <pdf> --to md` 取得文字）。
2. 提取核心資訊：
   - 課名、年級階段（國小/國中/高中）、文體（說明文/記敘文/議論文等）。
   - 篇章主旨、核心大意、重要概念與名詞。
   - 寫作特色與語文焦點（如空間觀察法、三明治說明結構、修辭手法等）。
3. 對齊 108 課綱：
   - 總綱與領綱核心素養代碼（如國-E-A2、國-E-B1等）。
   - 學習重點（學習表現、學習內容標記代碼）。
   - 議題融入（法治、品德、環境、性別等實質內涵）。

### 步驟 2：九大備課資產架構規劃

確保產出涵蓋以下九大教學資產：

1. **核心教學教案 (Lesson Plan)**：單元基本資訊＋40～45 分鐘課堂流程。
2. **結構化課堂學習單 (Guided Notes)**：名詞填空鷹架＋觀念比較表。
3. **課堂提問階梯表 (Bloom Taxonomy)**：基礎 3 題＋進階 2 題＋挑戰 1～2 題。
4. **分層隨堂測驗卷 (Assessments)**：A 卷基礎＋B 卷素養題組＋答案解析。
5. **合作學習分組任務卡 (Task Cards)**：3～4 組任務卡。
6. **考前一頁紙精華 (CheatSheet)**：核心概念＋案例速記＋5 大盲點對照。
7. **教學簡報 (Slide Deck)**：8～12 頁，一頁一核心概念。
8. **課程結構圖 (Mindmap Structure)**：標題一為主題，標題二為重點。
9. **Kahoot! 數位測驗題庫**：5 題情境快問快答，4 選項＋時間＋正解。

### 步驟 3：本機成品生成（genoffice，存工作資料夾）

1. **建資料夾**：一律輸出至本機 `<工作資料夾>/output/<課程單元名稱>/`，例如：
   - `output/<單元名稱>/docx/`
   - `output/<單元名稱>/pptx/`
   - `output/<單元名稱>/xlsx/`
   - `output/<單元名稱>/png/`
   - 不建立 Google Drive 資料夾，不呼叫任何 `drive:*` / `slides:*` 雲端工具。

2. **6 份 DOCX（genoffice）**：
   - 先寫 Markdown 原稿（`01_教案_<單元>.md` … `06_CheatSheet.md`），表格用 GFM。
   - 逐份轉 DOCX：
     `genoffice create --type docx --from 01_教案_<單元>.md --out output/<單元>/docx/01_教案_<單元>.docx`
   - 驗收：`genoffice docs check <docx>`＋`genoffice render <docx> --out output/<單元>/png/preview_docx` 看排版。

3. **1 份 PPTX（genoffice 設計 deck 流程）**：
   - `genoffice guide slides design` 取得規範 → 寫 `style.md`＋`outline.json`（8～12 頁）。
   - `genoffice slides check <outline.json|page.json>` 逐頁校驗。
   - `genoffice create --type pptx --spec <spec-dir> --out output/<單元>/pptx/07_教學簡報_<單元>.pptx`
   - 驗收：`genoffice render <pptx> --grid --out output/<單元>/png`＋`genoffice slides audit <pptx>`，有問題用 `slides apply` 修。

4. **課程結構圖 PNG（本機）**：
   - 優先用 `genoffice image "<單元>課程結構圖，繁中標題…" --out output/<單元>/png/08_課程結構圖_<單元>.png`。
   - 需精確文字結構時改用 Python matplotlib 輸出 PNG 至同目錄，務必指定系統 CJK 字型避免方框。
   - 可用 `genoffice media <png> --ask "文字是否清晰無亂碼"` 複核。

5. **Kahoot! XLSX（genoffice）**：
   - 準備 `kahoot.json`：`{sheets:[{name:"Kahoot",rows:[["Question","Answer 1","Answer 2","Answer 3","Answer 4","Time limit (sec)","Correct answer(s)"],…]}]}`，遵守 Question ≤120 字、選項 ≤75 字。
   - `genoffice create --type xlsx --from kahoot.json --header --out output/<單元>/xlsx/09_Kahoot_<單元>.xlsx`
   - 驗收：`genoffice sheet read <xlsx> --stats`＋`genoffice sheet check <xlsx>`。

### 步驟 4：成果彙整與回報

列出本機相對路徑，不給雲端連結：
1. `output/<單元>/docx/` 6 份 DOCX 檔名。
2. `output/<單元>/pptx/` 1 份 PPTX 檔名。
3. `output/<單元>/xlsx/` 1 份 XLSX 檔名。
4. `output/<單元>/png/` 結構圖＋預覽圖檔名。
5. 提醒：用 `genoffice open <file>` 開啟，或直接以 Word / PowerPoint 編輯。

## 常見陷阱與注意事項 (Gotchas)

- **不可上雲**：本版一律本機輸出，禁止呼叫 drive / slides / Gmail 等雲端 MCP。
- **先查 guide 再寫 ops**：寫 PPTX / XLSX / DOCX 進階樣式前先跑 `genoffice guide <slides|docs|sheets> [op]`，勿憑記憶猜欄位。
- **中文檔名**：DOCX / PPTX 內文用繁中，檔名可用底線連接，避免空白與特殊符號。
- **先 render 再交件**：回報完成前必須看過 `genoffice render` 預覽圖，確認無溢框、亂碼、表格破版。

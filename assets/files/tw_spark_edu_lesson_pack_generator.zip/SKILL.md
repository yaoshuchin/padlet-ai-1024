---
name: tw-spark-edu-lesson-pack-generator
description: 依據教材課本內容或教學章節PDF，自動規劃並輸出全套素養導向教學資源包（教案、學習單、課堂提問表、分層測驗卷、分組任務卡、考前精華筆記），並同步生成Google簡報、高解析度課程結構圖PNG、Kahoot試算表XLSX，自動歸檔至指定的Google Drive備課資料夾。當使用者要求由課本PDF/教材生成全套備課包、教學資源包、完整教案與配件，或將教材整理並存入Google Drive資料夾時使用。
allowed-tools: drive slides docs_agent
---

# 臺灣 K-12 全套備課包生成器 (tw-spark-edu-lesson-pack-generator)

專為臺灣國小、國中與高中教師打造的一站式備課工作流。能將任何教科書章節 PDF 或教材內容，自動轉化為完整 108 課綱素養導向教學套件，並自動輸出 Google 文件、Google 簡報、結構圖圖片與 Kahoot 試算表，直接歸檔至 Google Drive 備課資料夾。

## 適用情境 (When to Use)

- 使用者提供課本 PDF、課文內容、或指定年級單元主題，要求產出完整教案與教學配件。
- 使用者要求生成全套備課資源包（包含教案、學習單、Bloom 提問表、分層測驗卷、分組任務卡、CheatSheet）。
- 使用者要求將備課成果轉為 Google 文件、Google 簡報、結構圖 PNG、Kahoot XLSX 試算表，並整理至 Google Drive 指定資料夾。

## 執行流程 (Workflow Steps)

### 步驟 1：教材解析與課綱對齊

1. 閱讀使用者提供的課本內容或 PDF 文本。
2. 提取核心資訊：
   - 課名、年級階段（國小/國中/高中）、文體（說明文/記敘文/議論文等）。
   - 篇章主旨、核心大意、重要概念與名詞。
   - 寫作特色與語文焦點（如空間觀察法、三明治說明結構、修辭手法等）。
3. 對齊 108 課綱：
   - 總綱與領綱核心素養代碼（如國-E-A2、國-E-B1等）。
   - 學習重點（學習表現、學習內容標記代碼）。
   - 議題融入（法治、品德、環境、性別等實質內涵）。

### 步驟 2：九大備課資產架構規劃

確保產出涵蓋以下九大教學資產：

1. **核心教學教案 (Lesson Plan)**：
   - 單元基本資訊（年級、核心素養、學習重點、學習目標、議題融入）。
   - 40～45 分鐘課堂流程（引起動機 5m、核心概念發展 25m、統整歸納與評量 5m、課後延伸 5m）。
2. **結構化課堂學習單 (Guided Notes)**：
   - 單元一：名詞填空鷹架（保留前後文，挖空核心字詞）。
   - 單元二：觀念比較表格或流程步驟填空。
3. **課堂提問階梯表 (Bloom Taxonomy)**：
   - 基礎層（記憶/理解）：3 題課本事實與名詞定義。
   - 進階層（分析/應用）：2 題生活情境或寫作技巧應用。
   - 挑戰層（評鑑/創造）：1～2 題分組思辨或共創設計。
4. **分層隨堂測驗卷 (Assessments)**：
   - A 卷（基礎精熟）：單選題 3 題 + 是非改錯題 2 題。
   - B 卷（素養導向）：1 組生活情境題組（含 2 小題，附評分規準）。
   - 完整標準答案與詳細解析。
5. **合作學習分組任務卡 (Task Cards)**：
   - 3～4 組任務卡，包含：任務角色/情境（Role/Scenario）、具體待解決問題、產出成果形式（如短講、流程圖、心智圖）。
6. **考前一頁紙精華 (CheatSheet)**：
   - 核心概念與必背名詞定義。
   - 課本代表性案例速記表。
   - 5 大常見考試盲點與易混淆觀念對照表。
7. **教學簡報大綱 (Slide Outline)**：
   - 8～12 頁，恪守「一頁面一核心概念」原則。
   - 每頁含：頁面標題、條列要點、建議視覺圖表、課堂互動提示。
8. **課程結構圖 (Mindmap Structure)**：
   - 標題一為主題，標題二為重點，其餘為條列式層次。
9. **Kahoot! 數位測驗題庫**：
   - 5 題情境化快問快答，含題目、4 個選項（含幽默/具迷惑性誘答）、時間限制與正確答案。

### 步驟 3：多格式成品生成與 Drive 歸檔實作

1. **Google Drive 資料夾建置**：
   - 透過 `drive:search_files` 尋找使用者指定的父資料夾（如「備課資料夾」）。
   - 透過 `drive:create_file(mime_type="application/vnd.google-apps.folder", title="<課程單元名稱>")` 建立單元專屬資料夾。
   - 透過 `drive:update_file` 將其移入目標父資料夾。

2. **Google 文件轉換 (6 份文件)**：
   - 在本機工作目錄編寫結構完整、排版優雅的 HTML 檔案（含表格邊框、色彩標題、重點高亮）：
     - 01_教案_<單元名稱>.html
     - 02_學習單_<單元名稱>.html
     - 03_課堂提問階梯表_Bloom布魯姆認知層次.html
     - 04_隨堂測驗卷_A卷基礎與B卷素養.html
     - 05_分組任務卡_合作學習闖關.html
     - 06_考前一頁紙精華_CheatSheet.html
   - 透過 `drive:create_file(mime_type="text/html", base64_content="file://...", title="...")` 上傳，自動轉為原生 Google Doc。
   - 透過 `drive:update_file` 將檔案移至課程單元資料夾。

3. **Google 簡報生成 (1 份簡報)**：
   - 透過 `drive:create_file(mime_type="application/vnd.google-apps.presentation", title="07_教學簡報_<單元名稱>")` 建立簡報。
   - 移入課程單元資料夾。
   - 透過 `slides:update(doc_id=..., query=...)` 帶入完整的 8～12 頁簡報內容。

4. **課程結構圖圖片輸出 (PNG 圖片)**：
   - 使用 Python `matplotlib` 繪製高解析度結構卡片圖。
   - 指定中文字型避免亂碼（如 `/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc`）。
   - 儲存為 PNG 圖片後，透過 `drive:create_file(mime_type="image/png", base64_content="file://...")` 上傳並移入資料夾。

5. **Kahoot! 試算表輸出 (XLSX 檔案)**：
   - 使用 Python `openpyxl` 建立符合 Kahoot! 官方匯入標準之試算表：
     - 欄位 A: Question - max 120 characters
     - 欄位 B~E: Answer 1 ~ Answer 4 - max 75 characters
     - 欄位 F: Time limit (sec)
     - 欄位 G: Correct answer(s) (1-4)
   - 儲存為 XLSX 檔案後，透過 `drive:create_file(mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")` 上傳並移入資料夾。

### 步驟 4：成果彙整與回報

完成所有檔案移轉後，條列呈現：
1. 課程專屬 Google Drive 資料夾超連結。
2. 6 份 Google 文件的檔案名稱與直達連結。
3. 1 份 Google 簡報的檔案名稱與直達連結。
4. 課程結構圖 PNG 與 Kahoot 試算表 XLSX 的檔案名稱與下載連結。

## 常見陷阱與注意事項 (Gotchas)

- **字型遺失問題**：在沙盒環境中使用 matplotlib 繪製中文圖表時，不可使用預設英文字型，必須明確指定系統可用的 CJK 字型檔案路徑（如 Noto Sans CJK），否則中文會呈現方框或拋出警告。
- **HTML 轉 Google Doc 格式**：使用 `drive:create_file` 上傳 HTML 時，務必使用乾淨的 inline CSS，避免外部網路樣式庫，以確保轉換為 Google Doc 時表格與字體保留完整樣式。
- **檔案移動不可遺漏**：`drive:create_file` 預設將檔案建立於雲端根目錄，建立完成後必須隨即呼叫 `drive:update_file(fileId=..., parentId=...)` 將其歸入課程資料夾。
